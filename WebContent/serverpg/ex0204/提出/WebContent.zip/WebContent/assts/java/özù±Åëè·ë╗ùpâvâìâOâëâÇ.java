	Person[] people = {
		new Person("田中 亮太","高度情報処理科", 1),
		new Person("山田 美希","高度情報処理科", 2),
		new Person("鈴木 健太郎","高度情報処理科", 2),
		new Person("佐藤 さくら","高度情報処理科", 3),
		new Person("小林 太郎","情報処理科", 1),
		new Person("高橋 真理子","情報処理科", 2),
		new Person("渡辺 貴志","情報処理科", 2),
		new Person("伊藤 まどか","情報処理科", 2),
		new Person("中村 勇太","情報システム開発科", 2),
		new Person("斎藤 みゆき","情報システム開発科", 2)
	};